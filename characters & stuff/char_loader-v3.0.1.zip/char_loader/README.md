# Custom Character Loader
Custom Character Loader mod for Yomi Hustle
Adds the function addCustomChar(Name, ScenePath, ?ButtonName) that you can call on CharacterSelect.gd's _ready() to easily add your custom character to the menu
